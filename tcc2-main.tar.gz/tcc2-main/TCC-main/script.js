function darkMode() {
    const element = document.body;
    element.classList.toggle("darkmode");
 }